# inTrello

### Extension for Google Chrome which allow add CV from LinkedIn to Trello board
